const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('#navLinks');

menuToggle?.addEventListener('click', () => {
  const open = navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
});

document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks?.classList.remove('open');
    menuToggle?.setAttribute('aria-expanded', 'false');
  });
});

const form = document.querySelector('#commentForm');
const list = document.querySelector('#commentsList');
const STORAGE_KEY = 'festad-oro-comments';

function loadComments() {
  if (!list) return;
  const comments = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  list.innerHTML = '';

  if (!comments.length) {
    list.innerHTML = '<p class="muted" style="font-size:13px">Todavía no hay comentarios. ¡Sé la primera persona en dejar uno!</p>';
    return;
  }

  comments.slice().reverse().forEach(item => {
    const article = document.createElement('article');
    article.className = 'comment-item';

    const name = document.createElement('strong');
    name.textContent = item.name;

    const text = document.createElement('p');
    text.textContent = item.comment;

    const date = document.createElement('div');
    date.className = 'comment-date';
    date.textContent = item.date;

    article.append(name, text, date);
    list.appendChild(article);
  });
}

form?.addEventListener('submit', event => {
  event.preventDefault();

  const name = document.querySelector('#name').value.trim();
  const comment = document.querySelector('#comment').value.trim();

  if (!name || !comment) return;

  const comments = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');

  comments.push({
    name,
    comment,
    date: new Date().toLocaleDateString('es-PE', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })
  });

  localStorage.setItem(STORAGE_KEY, JSON.stringify(comments.slice(-20)));
  form.reset();
  loadComments();
});

loadComments();
