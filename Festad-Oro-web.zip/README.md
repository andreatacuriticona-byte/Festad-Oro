# Festad-Oro

Sitio web de Festad-Oro, panetón fortificado con hierro.

## Archivos
- `index.html`: estructura de la página.
- `styles.css`: diseño y responsive.
- `script.js`: menú móvil y comentarios locales.
- `assets/`: logo e ilustración del producto.

## Publicación
Configurado para GitHub Pages desde `main` / `/ (root)`.
